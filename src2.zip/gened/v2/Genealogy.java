package gened.v2;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;

import gened.utils.Person;

public class Genealogy {
	
	private JTree tree;
	private JFrame frame;
	
	public Genealogy() {
		createView();
		placeComponents();
		createController();
	}

	private void createView() {
		frame = new JFrame();
		frame.setPreferredSize(new Dimension(200,350));
		tree = new JTree(new DefaultTreeModel(new DefaultMutableTreeNode(new Person())));
		buildTree((MutableTreeNode) tree.getModel().getRoot(), 0);
	}
	
	private void buildTree(MutableTreeNode node, int index) {
		if (index >= 3) {
			return;
		}
		for (int i = 0; i<3 ; i+=1) {
			node.insert(new DefaultMutableTreeNode(new Person()), i);
			buildTree( (MutableTreeNode) node.getChildAt(i), index +1);
		}
	}

	private void placeComponents() {
		JScrollPane jsp = new JScrollPane();
		{
			jsp.setViewportView(tree);
		}
		frame.add(jsp, BorderLayout.CENTER);
	}

	private void createController() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		tree.addTreeSelectionListener(new TreeSelectionListener() {

			@Override
			public void valueChanged(TreeSelectionEvent e) {
				int[] r = tree.getSelectionRows();
				TreePath path = tree.getPathForRow(r[r.length - 1]);
				Object[] nodes = path.getPath();
				DefaultMutableTreeNode n = (DefaultMutableTreeNode)
						nodes[nodes.length - 1];
				Person p = (Person) n.getUserObject();
				String s = p.getName();
				StringBuffer b = new StringBuffer(s);
				for (int i = nodes.length - 1; i > 0; i--) {
					DefaultMutableTreeNode n2 = (DefaultMutableTreeNode)
							nodes[i];
					Person p2 = (Person) n2.getUserObject();
					DefaultMutableTreeNode n3 = (DefaultMutableTreeNode)
							nodes[i - 1];
					Person p3 = (Person) n3.getUserObject();
					b.append(", " + p2.getGender().getDesc() + " de " 
					+ p3.getName());
				}
				frame.setTitle(b.toString());
			}
			
			
		});
	}
	
	public void display() {
		frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
	}
	
	public static void main (String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new Genealogy().display();
			}
			
		});
	}

	
}
