package gened.v1;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;

public class Genealogy {
	
	private JTree tree;
	private JFrame frame;
	
	public Genealogy() {
		createView();
		placeComponents();
		createController();
	}

	private void createView() {
		frame = new JFrame();
		frame.setPreferredSize(new Dimension(200,350));
		tree = new JTree(new DefaultTreeModel(new DefaultMutableTreeNode("Toto")));
		buildTree((MutableTreeNode) tree.getModel().getRoot(), 0);
	}
	
	private void buildTree(MutableTreeNode node, int index) {
		if (index >= 3) {
			return;
		}
		for (int i = 0; i<3 ; i+=1) {
			node.insert(new DefaultMutableTreeNode("Toto"), i);
			buildTree( (MutableTreeNode) node.getChildAt(i), index +1);
		}
	}

	private void placeComponents() {
		JScrollPane jsp = new JScrollPane();
		{
			jsp.setViewportView(tree);
		}
		frame.add(jsp, BorderLayout.CENTER);
	}

	private void createController() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void display() {
		frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
	}
	
	public static void main (String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new Genealogy().display();
			}
			
		});
	}

	
}
