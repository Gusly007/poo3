package gened.v5;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import gened.utils.Person;

public class Genealogy {
	
	private GenTree tree;
	private JFrame frame;
	
	public Genealogy() {
		createView();
		placeComponents();
		createController();
	}

	private void createView() {
		frame = new JFrame();
		frame.setPreferredSize(new Dimension(200,350));
		tree = new GenTree();
		tree.setModel(new DefaultTreeModel(null));
	}

	private void placeComponents() {
		JScrollPane jsp = new JScrollPane();
		{
			jsp.setViewportView(tree);
		}
		frame.add(jsp, BorderLayout.CENTER);
	}

	private void createController() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		tree.addTreeSelectionListener(new TreeSelectionListener() {

			@Override
			public void valueChanged(TreeSelectionEvent e) {
				frame.setTitle(title());
			}
			
			
		});
		
		tree.getModel().addTreeModelListener(new TreeModelListener() {
			
			@Override
			public void treeNodesChanged(TreeModelEvent e) {
				frame.setTitle(title());
				
			}

			@Override
			public void treeNodesInserted(TreeModelEvent e) {
			}

			@Override
			public void treeNodesRemoved(TreeModelEvent e) {
			}

			@Override
			public void treeStructureChanged(TreeModelEvent e) {
			}
		});
	}
	
	private String title() {
		TreePath tp = tree.getSelectionPath();
		if (tp!=null) {
			DefaultMutableTreeNode node = (DefaultMutableTreeNode) tp.getLastPathComponent();
			Person p = (Person) node.getUserObject();
			StringBuffer sb = new StringBuffer(p.getName());
			DefaultMutableTreeNode parent = (DefaultMutableTreeNode) node.getParent();
			while (parent != null) {
				Person lastPerson = p;
				p = (Person) parent.getUserObject();
				sb.append(", " + lastPerson.getGender().getDesc() + " de " + p.getName());
				parent = (DefaultMutableTreeNode) parent.getParent();
			}
			return sb.toString();
		}
		return "";
	}
	
	public void display() {
		frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
	}
	
	public static void main (String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new Genealogy().display();
			}
			
		});
	}

	
}
