package gened.v5;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EnumMap;
import java.util.Map;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultTreeSelectionModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import gened.utils.DefaultTreeCellEditor2;
import gened.utils.GenCellEditor;
import gened.utils.GenCellRenderer;
import gened.utils.Person;

public class GenTree extends JTree {

    // ATTRIBUTS

    private static final long serialVersionUID = 1L;
	// tous les éléments du menu surgissant (qui correspondent aux
    // constantes de Item)
    private Map<Item, JMenuItem> menuItems;
    private JPopupMenu menu;

    // CONSTRUCTEURS

    public GenTree() {
        super((TreeNode) null);
        createView();
        createController();
        updateMenuItems();
    }

    // REQUETES

    @Override
    public DefaultTreeModel getModel() {
        return (DefaultTreeModel) super.getModel();
    }

    // OUTILS

    private void createView() {
    	menuItems = getMenuItemsMap();
        menu = createAndGetConfiguredPopupMenu();
    	this.setCellRenderer(new GenCellRenderer());
    	this.setEditable(true);
    	this.setCellEditor(new DefaultTreeCellEditor2(this, new GenCellRenderer(), new GenCellEditor()));
    	DefaultTreeSelectionModel selectionModel = new DefaultTreeSelectionModel();
    	selectionModel.setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    	this.setSelectionModel(selectionModel);
    	this.setComponentPopupMenu(menu);
    }

    private JPopupMenu createAndGetConfiguredPopupMenu() {
        JPopupMenu jp = new JPopupMenu();
        for (Item i: Item.STRUCT) {
        	if(i == null) {
        		jp.addSeparator();
        	} else {
        		jp.add(menuItems.get(i));
        	}
        }
        return jp;
    }
    
    private Map<Item, JMenuItem> getMenuItemsMap() {
        Map<Item,JMenuItem> map = new EnumMap<Item,JMenuItem>(Item.class);
        for (Item item: Item.values()) {
        	map.put(item, new JMenuItem(item.toString()));
        }
        return map;
    }

    private void createController() {
        // écoute les changements de sélection sur l'arbre,
        // pour mettre à jour l'état d'activabilité des éléments de menu
        this.addTreeSelectionListener(new TreeSelectionListener() {

			@Override
			public void valueChanged(TreeSelectionEvent e) {
				updateMenuItems();
			}
        	
        });
        
        // écoute les éléments de menu,
        // pour appliquer leur comportement sur l'arbre
        ActionListener al = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JMenuItem jmi = (JMenuItem) e.getSource();
				for (Item i: Item.values()) {
					if (jmi.getText().equals(i.toString())) {
						i.applyOn(GenTree.this);
						break;
					}
				}
			}
        	
        };
        
        for (JMenuItem jmi : menuItems.values()) {
            jmi.addActionListener(al);
        }
    }

    /**
     * Activation ou désactivation de chaque JMenuItem selon l'état de l'arbre.
     */
    private void updateMenuItems() {
        for (Map.Entry<Item, JMenuItem> entry : menuItems.entrySet()) {
            Item i = entry.getKey();
            JMenuItem jmi = entry.getValue();
            jmi.setEnabled(i.getEnabledValue(this));
        }
    }
    
    // TYPES IMBRIQUES

    private enum Item {
        CREATE_ROOT() {
            /**
             * Retourne true ssi t n'a pas de racine.
             */
            @Override boolean getEnabledValue(GenTree t) {
                return t.getModel().getRoot() == null;
            }
            /**
             * @pre t n'a pas de racine
             * @post t possède une nouvelle racine (de genre aléatoire),
             *       et cette racine est maintenant sélectionnée
             */
            @Override void applyOn(GenTree t) {
                assert getEnabledValue(t);
                
                t.getModel().setRoot(new DefaultMutableTreeNode(new Person()));
                t.setSelectionPath(new TreePath(t.getModel().getRoot()));
            }
        },
        CREATE_BROTHER_BEFORE() {
            /**
             * Retourne true ssi un nœud de t est sélectionné, et ce n'est pas
             *  la racine.
             */
            @Override boolean getEnabledValue(GenTree t) {
                DefaultTreeModel tm = t.getModel();
                TreePath path = t.getSelectionPath();
                if (path == null) {
                	return false;
                }
                if (tm.getRoot() != path.getLastPathComponent() && path.getLastPathComponent() != null) {
                	return true;
                }
                return false;
            }
            /**
             * @pre un nœud de t est sélectionné, et ce n'est pas la racine
             * @post t possède un nouveau nœud (de genre aléatoire) juste avant
             *       le nœud précédemment sélectionné, et ce nouveau nœud est
             *       maintenant sélectionné
             */
            @Override void applyOn(GenTree t) {
            	assert getEnabledValue(t);
            	
            	DefaultTreeModel tm = t.getModel();
            	DefaultMutableTreeNode selected = (DefaultMutableTreeNode) t.getSelectionPath().getLastPathComponent();
            	DefaultMutableTreeNode node = new DefaultMutableTreeNode(new Person());
            	DefaultMutableTreeNode parent = (DefaultMutableTreeNode) selected.getParent();
            	tm.insertNodeInto(node, parent, parent.getIndex(selected));
            	t.setSelectionPath(new TreePath(node.getPath()));
            }
        },
        CREATE_BROTHER_AFTER() {
            /**
             * Retourne true ssi un nœud de t est sélectionné, et ce n'est pas
             *  la racine.
             */
            @Override boolean getEnabledValue(GenTree t) {
            	DefaultTreeModel tm = t.getModel();
                TreePath path = t.getSelectionPath();
                if (path == null) {
                	return false;
                }
                return (tm.getRoot() != path.getLastPathComponent() && path.getLastPathComponent() != null);
            }
            /**
             * @pre un nœud de t est sélectionné, et ce n'est pas la racine
             * @post t possède un nouveau nœud (de genre aléatoire) juste après
             *       le nœud précédemment sélectionné, et ce nouveau nœud est
             *       maintenant sélectionné
             */
            @Override void applyOn(GenTree t) {
            	assert getEnabledValue(t);
            	
            	DefaultTreeModel tm = t.getModel();
            	DefaultMutableTreeNode selected = (DefaultMutableTreeNode) t.getSelectionPath().getLastPathComponent();
            	DefaultMutableTreeNode node = new DefaultMutableTreeNode(new Person());
            	DefaultMutableTreeNode parent = (DefaultMutableTreeNode) selected.getParent();
            	tm.insertNodeInto(node, parent, parent.getIndex(selected)+1);
            	t.setSelectionPath(new TreePath(node.getPath()));
            }
        },
        CREATE_FIRST_SON() {
            /**
             * Retourne true ssi un nœud de t est sélectionné, et qu'il n'a pas
             *  de fils.
             */
            @Override boolean getEnabledValue(GenTree t) {
            	TreePath path = t.getSelectionPath();
            	if (path == null) {
            		return false;
            	}
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                return node!=null && node.getChildCount() == 0;
            }
            /**
             * @pre un nœud de t est sélectionné, et il n'a pas de fils
             * @post t possède un nouveau nœud (de genre aléatoire) juste
             *       au-dessous du nœud précédemment sélectionné, et ce nouveau
             *       nœud est maintenant sélectionné
             */
            @Override void applyOn(GenTree t) {
            	assert getEnabledValue(t);
            	
            	DefaultMutableTreeNode selected = (DefaultMutableTreeNode) t.getSelectionPath().getLastPathComponent();
            	DefaultMutableTreeNode node = new DefaultMutableTreeNode(new Person());
            	t.getModel().insertNodeInto(node, selected, 0);
            	t.setSelectionPath(new TreePath(node.getPath()));
            }
        },
        DELETE_SELECTION() {
            /**
             * Retourne true ssi un nœud de t est sélectionné.
             */
            @Override boolean getEnabledValue(GenTree t) {
            	TreePath path = t.getSelectionPath();
            	if (path == null) {
            		return false;
            	}
                return path.getLastPathComponent() != null;
            }
            /**
             * @pre un nœud de t est sélectionné
             * @post le nœud qui était sélectionné dans t a été retiré,
             *       et plus aucun nœud de t n'est sélectionné
             */
            @Override void applyOn(GenTree t) {
            	assert getEnabledValue(t);
            	
            	DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) t.getSelectionPath().getLastPathComponent();
            	if (selectedNode == t.getModel().getRoot()) {
            		t.getModel().setRoot(null);
            		return;
            	}
            	t.getModel().removeNodeFromParent(selectedNode);
            	t.setSelectionPath(null);
            }
        };

        static final Item[] STRUCT = new Item[] {
                CREATE_ROOT, null,
                CREATE_FIRST_SON, null,
                CREATE_BROTHER_BEFORE, CREATE_BROTHER_AFTER, null,
                DELETE_SELECTION
        };
        
        @Override
        public String toString() {
            return name().toLowerCase().replace('_', ' ');
        }
        
        /**
         * Indique si le JMenuItem correspondant à this doit être activable
         *  ou non, en fonction de l'état de t.
         */
        abstract boolean getEnabledValue(GenTree t);

        /**
         * Applique sur t le comportement du JMenuItem correspondant à this.
         */
        abstract void applyOn(GenTree t);
    }
}
