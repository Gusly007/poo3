package layouts;

import static java.awt.Component.CENTER_ALIGNMENT;

import java.awt.Dimension;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class BoxDistrib extends Distrib {
    
    // CONSTANTES DE CLASSE

    private static final int EXTRA_SPACE = 38;
    private static final int BIG_SPACE = 12;
    private static final int SMALL_SPACE = 6;
    
    // ATTRIBUTS
    
    // Association entre les boutons de boisson et les labels qui les suivent
    private Map<JButton, JLabel> cmds;

    // CONSTRUCTEURS

    public BoxDistrib() {
        super("BoxDistrib de boisson");
    }

    // OUTILS

    @Override
    protected void createView(String title) {
        super.createView(title);
        cmds = createCmds();
        config();
    }
    
    /**
     * Construction de la map qui associe un label à chaque bouton de boisson.
     */
    private Map<JButton, JLabel> createCmds() {
        Map<JButton, JLabel> r = new LinkedHashMap<JButton, JLabel>();
        r.put(jb(B_ORANGE), jl(L_ORANGE));
        r.put(jb(B_CHOCO), jl(L_CHOCO));
        r.put(jb(B_COFFEE), jl(L_COFFEE));
        return r;
    }
    
    /**
     * Adapte la taille de certains composants :
     * - les boutons de boisson ont tous la largeur du plus large d'entre eux
     * - les boutons d'action (insert et cancel) ont la même largeur
     * 
     * - la largeur max des champs de texte reste infinie horizontalement,
     *   mais leur hauteur max est ramenée à leur hauteur préférée
     * 
     * - le bouton take sera horizontalement centré dans sa box verticale
     * - le label d'information sur le rendu de monnaie tout au nord
     *   sera horizontalement centré dans sa box verticale
     * - le label d'information sur le crédit actuel juste au dessous
     *   sera horizontalement centré dans sa box verticale.
     */
    private void config() {
        linkButtonSizes(jb(B_ORANGE), jb(B_CHOCO), jb(B_COFFEE));
        linkButtonSizes(jb(B_INSERT), jb(B_CANCEL));
        
        for (JTextField tf : jtfs()) {
            setHorizontallyExpandableOnly(tf);
        }
        
        setHorizontallyCentered(jb(B_TAKE), jl(L_INFO), jl(L_CREDIT));
    }

    /**
     * Tous les boutons passés en paramètre adoptent la largeur du plus large
     *  d'entre eux.
     */
    private static void linkButtonSizes(JButton... buttons) {
    	int max = 0;
        for (JButton button : buttons) {
            max = Math.max(max, button.getPreferredSize().width);
        }
        for (JButton button : buttons) {
        	Dimension d = button.getPreferredSize();
        	d.setSize(max, d.getHeight());
            button.setMaximumSize(d);
        }
    }
    
    /**
     * La largeur maximale de tf reste la même (l'infini), mais sa hauteur
     *  maximale est ramenée à sa hauteur préférée.
     */
    private static void setHorizontallyExpandableOnly(JTextField tf) {
    	Dimension d = tf.getMaximumSize();
    	d.setSize(d.getWidth(), tf.getPreferredSize().getHeight());
        tf.setMaximumSize(d);
    }
    
    /**
     * Tous les composants passés en paramètre sont configurés pour se centrer
     *  horizontalement dans une boite verticale.
     */
    private static void setHorizontallyCentered(JComponent... comps) {
    	 for (JComponent comp : comps) {
    		 comp.setAlignmentX(CENTER_ALIGNMENT);
    	 }
    }

    @Override
    protected void placeComponents() {
       Box b1 = Box.createVerticalBox();
       {
    	   b1.add(Box.createRigidArea(new Dimension(0,BIG_SPACE)));
    	   b1.add(jl(L_INFO));
    	   b1.add(Box.createRigidArea(new Dimension(0,BIG_SPACE)));
    	   b1.add(jl(L_CREDIT));
    	   b1.add(Box.createRigidArea(new Dimension(0,BIG_SPACE)));
    	   Box b2 = Box.createHorizontalBox();
    	   {
    		   b2.add(Box.createRigidArea(new Dimension(BIG_SPACE,0)));
    		   Box b3 = Box.createVerticalBox();
    		   {
    			   Box b4 = null;
    			   for (JButton jb: cmds.keySet()) {
    				   b4 = Box.createHorizontalBox();
    				   {
    					   b4.setAlignmentX(Box.LEFT_ALIGNMENT);
    					   b4.add(jb);
    					   b4.add(Box.createRigidArea(new Dimension(SMALL_SPACE,0)));
    					   b4.add(cmds.get(jb));
    				   }
    				   b3.add(b4);
    				   b3.add(Box.createRigidArea(new Dimension(0,SMALL_SPACE)));
    			   }
    			   b4 = Box.createHorizontalBox();
    			   {
    				   b4.setAlignmentX(Box.LEFT_ALIGNMENT);
    				   b4.add(jl(L_DRINK));
    				   b4.add(Box.createRigidArea(new Dimension(SMALL_SPACE,0)));
    				   b4.add(jtf(F_DRINK));
    			   }
    			   b3.add(b4);
    		   }
    		   b2.add(b3);
    		   b2.add(Box.createRigidArea(new Dimension(BIG_SPACE,0)));
    		   b3 = Box.createVerticalBox();
    		   {
    			   Box b4 = Box.createHorizontalBox();
    			   {	
    				   b4.setAlignmentX(Box.LEFT_ALIGNMENT);
    				   b4.add(jb(B_INSERT));
    				   b4.add(Box.createRigidArea(new Dimension(SMALL_SPACE,0)));
    				   b4.add(jtf(F_INSERT));
    				   b4.add(Box.createRigidArea(new Dimension(SMALL_SPACE,0)));
    				   b4.add(jl(L_INSERT));
    			   }
    			   b3.add(b4);
    			   b3.add(Box.createRigidArea(new Dimension(0,SMALL_SPACE)));
    			   b4 = Box.createHorizontalBox();
    			   {
    				   b4.setAlignmentX(Box.LEFT_ALIGNMENT);
    				   b4.add(jb(B_CANCEL));
    			   }
    			   b3.add(b4);
    			   b3.add(Box.createRigidArea(new Dimension(0,EXTRA_SPACE)));
    			   b4 = Box.createHorizontalBox();
    			   {
    				   b4.setAlignmentX(Box.LEFT_ALIGNMENT);
    				   b4.add(jl(L_BACK_PRE));
    				   b4.add(Box.createRigidArea(new Dimension(SMALL_SPACE,0)));
    				   b4.add(jtf(F_BACK));
    				   b4.add(Box.createRigidArea(new Dimension(SMALL_SPACE,0)));
    				   b4.add(jl(L_BACK_POST));
    			   }
    			   b3.add(b4);
    		   }
    		   b2.add(b3);
    		   b2.add(Box.createRigidArea(new Dimension(BIG_SPACE,0)));
    	   }
    	   b1.add(b2);
    	   b1.add(Box.createRigidArea(new Dimension(0,BIG_SPACE)));
    	   b1.add(jb(B_TAKE));
    	   b1.add(Box.createVerticalStrut(BIG_SPACE));
    	   b1.add(Box.createVerticalGlue());
       }
       frame().add(b1);
    }

    // POINT D'ENTREE

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BoxDistrib().display();
            }
        });
    }
}
