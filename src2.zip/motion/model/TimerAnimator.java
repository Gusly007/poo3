package motion.model;

import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import util.Contract;

public class TimerAnimator extends AbstractAnimator implements Animator {
	
	private int speed;
	private boolean started;
	private boolean stopped;
	private boolean paused;
	private Timer timer;
	
	public TimerAnimator(int max) {
		super(testMax(max));
		speed = max/2;
		timer = new Timer(sleepDuration(), new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireTickOccured();
			}
		});
		timer.setInitialDelay(0);
	}

	@Override
	public int getSpeed() {
		return speed;
	}

	@Override
	public boolean hasStarted() {
		return started;
	}

	@Override
	public boolean hasStopped() {
		return hasStarted() && stopped;
	}

	@Override
	public boolean isPaused() {
		return isRunning() && paused;
	}

	@Override
	public boolean isResumed() {
		return isRunning() && !paused;
	}

	@Override
	public boolean isRunning() {
		return hasStarted() && !hasStopped();
	}

	@Override
	public void pause() {
		Contract.checkCondition(isRunning());
		timer.stop();
		paused = true;
		fireStateChanged();
	}

	@Override
	public void resume() {
		Contract.checkCondition(isRunning(), "started = " + started + "; stopped = " + stopped + "; paused = " + paused);
		timer.start();
		paused = false;
		fireStateChanged();
	}

	@Override
	public void setSpeed(int d) {
		Contract.checkCondition(d >= 0 && d <= getMaxSpeed());
		speed = d;
		timer.setDelay(sleepDuration());
	}

	@Override
	public void start() {
		started = true;
		paused = false;
		timer.start();
		fireStateChanged();
	}

	@Override
	public void stop() {
		Contract.checkCondition(isRunning());
		stopped = true;
		timer.stop();
		fireStateChanged();
	}
	
	private static int testMax(int max) {
		Contract.checkCondition(max > 0);
		return max;
	}

}
