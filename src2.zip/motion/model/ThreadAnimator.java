package motion.model;

import util.Contract;

public class ThreadAnimator extends AbstractAnimator implements Animator {
	
	private int speed;
	private boolean started;
	private boolean stopped;
	private boolean paused;
	private Thread thread;
	private volatile int delay;
	
	public ThreadAnimator(int max) {
		super(testMax(max));
		speed = max/2;
		delay = sleepDuration();
		thread = new Thread(new TickLoop());
	}

	@Override
	public int getSpeed() {
		return speed;
	}

	@Override
	public synchronized boolean hasStarted() {
		return started;
	}

	@Override
	public synchronized boolean hasStopped() {
		return hasStarted() && stopped;
	}

	@Override
	public synchronized boolean isPaused() {
		return isRunning() && paused;
	}

	@Override
	public synchronized boolean isResumed() {
		return isRunning() && !paused;
	}

	@Override
	public synchronized boolean isRunning() {
		return hasStarted() && !hasStopped();
	}

	@Override
	public synchronized void pause() {
		Contract.checkCondition(isRunning());
		paused = true;
		fireStateChanged();
	}

	@Override
	public synchronized void resume() {
		Contract.checkCondition(isRunning(), "started = " + started + "; stopped = " + stopped + "; paused = " + paused);
		paused = false;
		this.notifyAll();
		fireStateChanged();
	}

	@Override
	public synchronized void setSpeed(int d) {
		Contract.checkCondition(d >= 0 && d <= getMaxSpeed());
		speed = d;
		delay = sleepDuration();
	}

	@Override
	public synchronized void start() {
		started = true;
		paused = false;
		fireStateChanged();
		thread.start();
	}

	@Override
	public synchronized void stop() {
		Contract.checkCondition(isRunning());
		stopped = true;
		thread.interrupt();
		fireStateChanged();
	}
	
	private static int testMax(int max) {
		Contract.checkCondition(max > 0);
		return max;
	}
	
	class TickLoop implements Runnable{

		@Override
		public void run() {
			while(!hasStopped()) {
				if(isPaused()) {
					synchronized(ThreadAnimator.this) {
						try {
							ThreadAnimator.this.wait();
						} catch (InterruptedException e) {
							//rien
						}
					}
				} else {		
					fireTickOccured();
					try {
						Thread.sleep(delay);
					} catch (InterruptedException e) {
					}
				}
				
			}
			
		}

	}

}
