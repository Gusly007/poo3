package serie01;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class EventsTester {
	private JFrame mainFrame;
	private JFrame testFrame;
	private JButton btnNewTestFrame;
	private JButton reset;
	private int counter;
	private JTextArea mouseL;
	private JTextArea windowFL;
	private JTextArea windowL;
	private JTextArea keyL;
	private JTextArea windowSL;
	private JTextArea mouseWL;
	private JTextArea mouseML;
	private List<JTextArea> areas;
	private Map<String, JTextArea> areaNames;
	
	public EventsTester() {
		createView();
		placeComponents();
		createController();
	}
	
	public void display() {
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    	createNewTestFrame();
	}

	private void createView() {
		mainFrame = new JFrame("Test sur les évènements - Zone d'AFFICHAGE");
		btnNewTestFrame = new JButton("Nouvelle Fenêtre");
		reset = new JButton("RAZ Compteur");
		areas = new ArrayList<JTextArea>();
		areaNames = new HashMap<String,JTextArea>();
		mouseL = new JTextArea(10,15);
		areas.add(mouseL);
		areaNames.put("Mouse", mouseL);
		windowFL = new JTextArea(10,15);
		areas.add(windowFL);
		areaNames.put("WindowFocus", windowFL);
		windowL = new JTextArea(10,15);
		areas.add(windowL);
		areaNames.put("Window", windowL);
		keyL = new JTextArea(10,15);
		areas.add(keyL);
		areaNames.put("Key", keyL);
		windowSL = new JTextArea(10,15);
		areas.add(windowSL);
		areaNames.put("WindowState", windowSL);
		mouseWL = new JTextArea(10,15);
		areas.add(mouseWL);
		areaNames.put("MouseWheel", mouseWL);
		mouseML = new JTextArea(10,15);
		areas.add(mouseML);
		areaNames.put("MouseMotion", mouseML);
		counter = 1;
	}

	private void placeComponents() {
		JPanel p = new JPanel();
		{
			p.add(btnNewTestFrame);
			p.add(reset);
		}
		mainFrame.add(p, BorderLayout.NORTH);
		p = new JPanel(new GridLayout(0,3));
		{
			String[] names = {"MouseListener", "WindowFocusListener", "WindowListener",
					"KeyListener", "WindowStateListener", "MouseWheelListener", "MouseMotionListener"};
			int index = 0;
			for (JTextArea area: areas) {
				JScrollPane sp = new JScrollPane(); {
				    sp.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), names[index]));
				    sp.setViewportView(area);
				    index += 1;
				}
				p.add(sp);
			}
		}
		mainFrame.add(p, BorderLayout.CENTER);
	}

	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		btnNewTestFrame.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (testFrame != null) {
					if (JOptionPane.showConfirmDialog(null,
							"Souhaitez-vous fermer la fenêtre de test?",
							"Confirmation",
							JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
						testFrame.dispose();
						for (JTextArea a: areas) {
							a.setText("");
						}
						counter = 0;
						createNewTestFrame();
					}
				} else {
					createNewTestFrame();
				}
			}	
		});
		
		reset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				counter = 1;
				for (JTextArea a: areas) {
					a.append("---RAZ---\n");
				}
			}
			
		});
		
	}
	
	private void createNewTestFrame() {
		testFrame = new JFrame("Zone de test");
		testFrame.setPreferredSize(new Dimension(200,100));
		testFrame.pack();
        testFrame.setVisible(true);
        testFrame.setLocationRelativeTo(null);
        testFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        testFrame.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleEvent("MOUSE_CLICKED", "Mouse");
			}

			@Override
			public void mousePressed(MouseEvent e) {
				handleEvent("MOUSE_PRESSED", "Mouse");
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				handleEvent("MOUSE_RELEASED", "Mouse");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				handleEvent("MOUSE_ENTERED", "Mouse");
			}

			@Override
			public void mouseExited(MouseEvent e) {
				handleEvent("MOUSE_EXITED", "Mouse");
			}
		});
        
        testFrame.addMouseMotionListener(new MouseMotionListener() {

			@Override
			public void mouseDragged(MouseEvent e) {
				handleEvent("MOUSE_DRAGGED", "MouseMotion");
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				handleEvent("MOUSE_MOVED", "MouseMotion");
			}
        	
        });
        
        testFrame.addMouseWheelListener(new MouseWheelListener() {

			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				handleEvent("MOUSE_WHEEL_MOVED", "MouseWheel");
			}
        	
        });
        
        testFrame.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				handleEvent("KEY_TYPED", "Key");
			}

			@Override
			public void keyPressed(KeyEvent e) {
				handleEvent("KEY_PRESSED", "Key");
			}

			@Override
			public void keyReleased(KeyEvent e) {
				handleEvent("KEY_RELEASED", "Key");
			}
        	
        });
        
        testFrame.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {
				handleEvent("WINDOW_OPENED", "Window");
			}

			@Override
			public void windowClosing(WindowEvent e) {
				handleEvent("WINDOW_CLOSING", "Window");
				testFrame = null;
			}

			@Override
			public void windowClosed(WindowEvent e) {
				handleEvent("WINDOW_CLOSED", "Window");
			}

			@Override
			public void windowIconified(WindowEvent e) {
				handleEvent("WINDOW_ICONIFIED", "Window");				
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				handleEvent("WINDOW_DEICONIFIED", "Window");
			}

			@Override
			public void windowActivated(WindowEvent e) {
				handleEvent("WINDOW_ACTIVATED", "Window");
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				handleEvent("WINDOW_DEACTIVATED", "Window");
			}
        	
        });
        
        testFrame.addWindowFocusListener(new WindowFocusListener() {

			@Override
			public void windowGainedFocus(WindowEvent e) {
				handleEvent("WINDOW_GAINED_FOCUS", "WindowFocus");
			}

			@Override
			public void windowLostFocus(WindowEvent e) {
				handleEvent("WINDOW_LOST_FOCUS", "WindowFocus");
			}
        	
        });
        
        testFrame.addWindowStateListener(new WindowStateListener() {

			@Override
			public void windowStateChanged(WindowEvent e) {
				handleEvent("WINDOW_STATE_CHANGED", "WindowState");				
			}
        	
        });
	}
	
	private void handleEvent(String name, String areaName) {
		JTextArea a = areaNames.get(areaName);
		a.append(String.valueOf(counter) + " " + name + "\n");
		counter += 1;
	}
	
	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new EventsTester().display();
            }
        });
    }
}
