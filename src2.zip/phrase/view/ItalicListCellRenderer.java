package phrase.view;

import java.awt.Component;
import java.awt.Font;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import phrase.model.StdMarkableListModel;

public class ItalicListCellRenderer implements ListCellRenderer<String> {
	
	private DefaultListCellRenderer delegate;
	
	public ItalicListCellRenderer() {
		delegate = new DefaultListCellRenderer();
	}

	@Override
	public Component getListCellRendererComponent(JList<? extends String> list, String value, int index,
			boolean isSelected, boolean cellHasFocus) {
		Component result = delegate.getListCellRendererComponent(list, value,
				index, isSelected, cellHasFocus);
		StdMarkableListModel listModel = (StdMarkableListModel) list.getModel();
		if (listModel.isMarked(value)) {
			result.setFont(result.getFont().deriveFont(Font.ITALIC));
		} else {
			result.setFont(result.getFont().deriveFont(Font.BOLD));
		}
		return result;
	}

}
