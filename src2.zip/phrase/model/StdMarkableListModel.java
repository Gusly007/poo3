package phrase.model;

import java.util.HashSet;
import java.util.Set;

import util.Contract;

public class StdMarkableListModel extends StdFilteringListModel implements FilteringListModel {
	
	private Set<String> markedElems;
	
	public StdMarkableListModel() {
		super();
		markedElems = new HashSet<String>();
	}
	
	public boolean isMarked(String s) {
		Contract.checkCondition(s!=null);
		return markedElems.contains(s);
	}
	
	public void toggleMarked(String s) {
		Contract.checkCondition(s!=null);
		if (isMarked(s)) {
			markedElems.remove(s);
		} else {
			markedElems.add(s);
		}
		fireContentsChanged(this, 0, 0);
	}
}
